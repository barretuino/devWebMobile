class ResultPaymentSlip {
  double fee;
  double interest;
  double value;
  int days;

  ResultPaymentSlip({
    this.fee = 0.0,
    this.interest = 0.0,
    this.value = 0.0,
    this.days = 0,
  });
}
