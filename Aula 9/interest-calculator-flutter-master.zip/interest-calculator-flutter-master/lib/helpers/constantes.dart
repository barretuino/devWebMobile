class Constantes {
  static const List<String> rateLabels = ['R\$', '%'];
  static const List<String> periodLabels = ['Dia', 'Mês'];
}
