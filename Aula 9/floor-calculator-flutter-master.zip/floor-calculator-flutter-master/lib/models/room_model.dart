class RoomModel {
  double width;
  double length;

  RoomModel({
    this.width = 0.0,
    this.length = 0.0,
  });
}
