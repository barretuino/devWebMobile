class Player {
  String name;
  int score;
  int victories;

  Player({this.name, this.score, this.victories});
}