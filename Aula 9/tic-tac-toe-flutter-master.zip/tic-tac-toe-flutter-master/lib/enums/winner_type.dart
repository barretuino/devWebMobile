enum WinnerType { none, player1, player2 }
