enum PlayerType { player1, player2 }
