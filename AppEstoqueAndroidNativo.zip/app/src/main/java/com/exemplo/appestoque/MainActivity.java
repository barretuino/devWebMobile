package com.exemplo.appestoque;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.exemplo.appestoque.model.Produto;
import com.exemplo.appestoque.network.ProdutoApiClient;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private EditText editNome, editPreco, editQuantidade;
    private Button btnSalvar, btnConsultar;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editNome = findViewById(R.id.editNome);
        editPreco = findViewById(R.id.editPreco);
        editQuantidade = findViewById(R.id.editQuantidade);
        btnSalvar = findViewById(R.id.btnSalvar);
        btnConsultar = findViewById(R.id.btnConsultar);

        btnSalvar.setOnClickListener(v -> {
            String nome = editNome.getText().toString().trim();
            String precoStr = editPreco.getText().toString().trim();
            String qtdStr = editQuantidade.getText().toString().trim();

            if (nome.isEmpty() || precoStr.isEmpty() || qtdStr.isEmpty()) {
                Toast.makeText(MainActivity.this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                return;
            }

            double preco = Double.parseDouble(precoStr);
            int quantidade = Integer.parseInt(qtdStr);

            Produto produto = new Produto(nome, preco, quantidade);

            executor.execute(() -> {
                boolean sucesso = ProdutoApiClient.salvarProduto(produto);

                runOnUiThread(() -> {
                    if (sucesso) {
                        Toast.makeText(MainActivity.this, "Produto salvo com sucesso!", Toast.LENGTH_SHORT).show();
                        editNome.setText("");
                        editPreco.setText("");
                        editQuantidade.setText("");
                    } else {
                        Toast.makeText(MainActivity.this, "Erro ao salvar produto.", Toast.LENGTH_SHORT).show();
                    }
                });
            });
        });

        btnConsultar.setOnClickListener(v -> {
            executor.execute(() -> {
                List<Produto> produtos = ProdutoApiClient.listarProdutos();

                Log.d("APP_CONSULTA", "--- Lista de Produtos Cadastrados ---");
                for (Produto p : produtos) {
                    Log.d("APP_CONSULTA", "ID: " + p.getId() + " | Nome: " + p.getNome() + " | Preço: R$ " + p.getPreco() + " | Qtd: " + p.getQuantidade());
                }

                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "Consulta realizada! Verifique o Logcat (" + produtos.size() + " itens).", Toast.LENGTH_LONG).show();
                });
            });
        });
    }
}
