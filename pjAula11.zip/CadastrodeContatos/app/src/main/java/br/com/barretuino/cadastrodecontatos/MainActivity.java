package br.com.barretuino.cadastrodecontatos;

import android.app.AlertDialog;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
//Importando Widget para recuperação dos componentes visuais do activity_main.xml
import android.widget.*;
//Importando a classe View que permitirá o tratamento de ações (está classe é Pai de todos os componentes Gráficos)
import android.view.View;

public class MainActivity extends AppCompatActivity {

    //Atributos
    private EditText txtNome, txtTelefone, txtEmail, txtDataNascimento;
    private RadioButton opcReceberNovidades;
    private Button btConfirmar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Recuperando os valores da view
        txtNome = (EditText) findViewById(R.id.txtNome);
        txtTelefone = (EditText) findViewById(R.id.txtTelefone);
        txtEmail = (EditText) findViewById(R.id.txtEmail);
        txtDataNascimento = (EditText) findViewById(R.id.txtDataNascimento);
        opcReceberNovidades = (RadioButton) findViewById(R.id.rdbSim);
        btConfirmar = (Button) findViewById(R.id.btConfirmar);

        btConfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder dialogo = new AlertDialog.Builder(MainActivity.this);

                String mensagem = "Nome " + txtNome.getText().toString() +
                                  " Email " + txtEmail.getText().toString() +
                                  " Telefone " + txtTelefone.getText().toString() +
                                  " Data Nascimento " + txtDataNascimento.getText().toString() +
                                  " Receber Novidades " + (opcReceberNovidades.isSelected() ? "Sim" : "Não");

                dialogo.setMessage(mensagem);
                dialogo.setNeutralButton("OK", null);
                dialogo.show();
            }
        });

                Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
