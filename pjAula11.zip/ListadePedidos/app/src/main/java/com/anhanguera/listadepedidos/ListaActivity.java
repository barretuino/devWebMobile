package com.anhanguera.listadepedidos;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;


public class ListaActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);

        EditText txtNome = (EditText)findViewById(R.id.txtNome);
        final RadioButton optRefrigerante = (RadioButton) findViewById(R.id.optRefrigerante);
        final RadioButton optRefrigerante2 = (RadioButton) findViewById(R.id.optRefrigerante2);
        final RadioButton optRefrigerante3 = (RadioButton) findViewById(R.id.optRefrigerante3);
        final RadioButton optBigMac = (RadioButton) findViewById(R.id.optBigMac);
        final RadioButton optSeiLa = (RadioButton) findViewById(R.id.optSeiQualquer);

        Button btSalvar = (Button) findViewById(R.id.btSalvar);
        final TextView resultado = (TextView) findViewById(R.id.lbPedido);

        //Tratamento de Ação do RadionButton selecionado
        btSalvar.setOnClickListener(new Button.OnClickListener(){
            //Ações
            public void onClick(View v){
                String texto = new String();

                if(optRefrigerante.isChecked()){
                    texto += "Pediu Coca";
                }
                if(optRefrigerante2.isChecked()){
                    texto += "Pediu Fanta";
                }
                if(optRefrigerante3.isChecked()){
                    texto += "Pediu Dolly";
                }
                if(optBigMac.isChecked()){
                    texto += "Pediu BigMac";
                }
                if(optSeiLa.isChecked()){
                    texto += "Pediu SeiLá";
                }

                resultado.setText(texto);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_lista, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
