package br.livro.android.cap11;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import br.livro.android.cap11.service.ExemploServico_IntentService;

/**
 * Exemplo de como utilizar os m�todos startService(intent) e
 * stopService(intent)
 * 
 * Vai chamar a classe "ExemploServico_IntentService" que foi criada com um IntentService
 * 
 * @author ricardo
 * 
 */
public class ExemploIniciarServico_IntentService extends Activity {
	private static final String CATEGORIA = "livro";

	@Override
	protected void onCreate(Bundle icicle) {
		super.onCreate(icicle);

		setContentView(R.layout.form_start_stop);

		// A mesma intent � utilizada para iniciar e parar
		final Intent it = new Intent(this,ExemploServico_IntentService.class);

		Button bIniciar = (Button) findViewById(R.id.btIniciar);
		bIniciar.setOnClickListener(new Button.OnClickListener() {
			public void onClick(View v) {
				// iniciar o servi�o
				startService(it);
			}
		});

		Button bParar = (Button) findViewById(R.id.btParar);
		bParar.setOnClickListener(new Button.OnClickListener() {
			public void onClick(View v) {
				// parar o servi�o
				stopService(it);
			}
		});
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		Log.i(CATEGORIA, "ExemploIniciarServico.onDestroy()");
	}
}
