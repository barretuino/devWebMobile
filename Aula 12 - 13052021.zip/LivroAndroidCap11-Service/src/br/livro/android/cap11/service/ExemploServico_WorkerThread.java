package br.livro.android.cap11.service;

import java.util.ArrayList;
import java.util.List;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

/**
 * Service simples que exibe logs no m�todo onCreate, onDestroy
 * 
 * O onCreate cria uma Thread para demonstrar um processamento em background
 * 
 * @author ricardo
 * 
 */
public class ExemploServico_WorkerThread extends Service {
	private static final int MAX = 10;
	private static final String CATEGORIA = "livro";
	private List<WorkerThread> threads = new ArrayList<WorkerThread>();

	@Override
	public IBinder onBind(Intent i) {
		Log.i(CATEGORIA, "ExemploServico_WorkerThread.onBind()");
		// Retorna null aqui porque n�o queremos interagir com o service
		return null;
	}

	@Override
	public void onCreate() {
		// Chamado apenas uma vez (independente de quantas vezes � chamado o startService(intent)
		Log.i(CATEGORIA, "ExemploServico_WorkerThread.onCreate()");
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// Chamado todas as vezes que o � chamado startService(intent)
		Log.i(CATEGORIA, "ExemploServico_WorkerThread.onStartCommand(): " + startId);
		// Delega para uma thread (criamos o nome para visualizar no debug do eclipse se necess�rio)
		WorkerThread workerThread = new WorkerThread(startId);
		threads.add(workerThread);
		workerThread.start();

		// API Level 5 ou superior
		return super.onStartCommand(intent, flags, startId);
	}
	
	// Uma inner class pode acessar todos os atributos da classe principal
	class WorkerThread extends Thread {
		private boolean ativo;
		private int startId;
		private int count;

		public WorkerThread(int startId) {
			super("ExemploServico-"+startId);
			this.startId = startId;
			ativo = true;
		}

		/**
		 * @see java.lang.Runnable#run()
		 */
		public void run() {
			while (ativo && this.count < MAX) {
				try {
					// Simula algum processamento (chamada para um web service ou banco de dados)
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				Log.i(CATEGORIA, startId + ": ExemploServico executando... " + this.count);

				this.count++;
			}

			Log.i(CATEGORIA, "ExemploServico fim ("+startId+")");

			// Auto-Encerra o service quando o processamento terminar
			stopSelf(startId);
		}
	}
	
	@Override
	public void onDestroy() {
		Log.i(CATEGORIA, "ExemploServico_WorkerThread.onDestroy()");

		// Esta chamada � �nica para todas as threads (cada chamado ao startService)
		// Ao encerrar o servi�o, altera o flag para as threads pararem
		for (WorkerThread workerThread : threads) {
			workerThread.ativo = false;
		}
		threads.clear();

	}
}
