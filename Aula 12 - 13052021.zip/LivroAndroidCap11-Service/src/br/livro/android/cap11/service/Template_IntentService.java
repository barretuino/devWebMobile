package br.livro.android.cap11.service;

import android.app.IntentService;
import android.content.Intent;

/**
 * Template com Intent Service
 * 
 * @author ricardo
 * 
 */
public class Template_IntentService extends IntentService {
	
	public Template_IntentService() {
		super("NomeDaThreadAqui");
	}

	@Override
	protected void onHandleIntent(Intent intent) {
		// Este m�todo executa em uma thread
		// Quando ele terminar, o m�todo stopSelf() ser� chamado automaticamente
		
		// Fa�a o que tem que fazer aqui
	}
}
