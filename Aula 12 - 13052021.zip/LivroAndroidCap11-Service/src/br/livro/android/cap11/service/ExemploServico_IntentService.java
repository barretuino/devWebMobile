package br.livro.android.cap11.service;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;

/**
 * Service simples que exibe logs no m�todo onCreate, onDestroy
 * 
 * Utiliza a classe IntentService, assim uma fila � criada para atender a cada chamada, em uma thread separada
 * 
 * Voc� n�o precisa criar a thread, e n�o precisa chamar o stopSelf;
 * 
 * @author ricardo
 * 
 */
public class ExemploServico_IntentService extends IntentService {
	
	public ExemploServico_IntentService() {
		super("NomeDaThreadAqui");
	}

	private static final int MAX = 10;
	private static final String CATEGORIA = "livro";
	protected int count;
	private boolean ativo;

	@Override
	protected void onHandleIntent(Intent intent) {
		ativo = true;

		// Este m�todo executa em uma thread
		// Quando ele terminar, o m�todo stopSelf() ser� chamado automaticamente
		while (ativo && count < MAX) {
			fazAlgumaCoisa();

			Log.i(CATEGORIA, "ExemploServico executando... " + count);

			count++;
		}

		Log.i(CATEGORIA, "ExemploServico fim.");
	}

	private void fazAlgumaCoisa() {
		try {
			// simula algum processamento
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		// Ao encerrar o servi�o, altera o flag para a thread parar
		ativo = false;
		Log.i(CATEGORIA, "ExemploServico.onDestroy()");
	}
}
