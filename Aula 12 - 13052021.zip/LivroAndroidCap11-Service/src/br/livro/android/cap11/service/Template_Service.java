package br.livro.android.cap11.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

/**
 * Service simples que exibe logs no m�todo onCreate, onDestroy
 * 
 * O onCreate cria uma Thread para demonstrar um processamento em background
 * 
 * @author ricardo
 * 
 */
public class Template_Service extends Service implements Runnable {
	private int startId;

	@Override
	public IBinder onBind(Intent i) {
		// null porque n�o queremos interagir com o service
		return null;
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// API Level 5 ou superior
		this.startId = startId;

		// Delega para uma thread
		new Thread(this).start();

		return super.onStartCommand(intent, flags, startId);
	}

	/**
	 * THREAD!
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		// Fa�a o que tem que fazer aqui

		// Auto-Encerra o service se o contadador chegou a 10
		stopSelf();
		
		// Se quiser voc� pode parar apensa o "id" especificado
		stopSelf(startId);
	}
}
