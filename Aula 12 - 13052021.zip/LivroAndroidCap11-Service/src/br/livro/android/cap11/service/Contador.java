package br.livro.android.cap11.service;

/**
 * Interface para utilizar com o m�todo binService para invocar
 * m�todos do Service
 * 
 * @author ricardo
 *
 */
public interface Contador {
	public int count();
}
