/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: R:\\Java\\workspaces\\workspace-livro\\LivroAndroidCap11-Service\\src\\br\\livro\\android\\cap11\\service\\aidl\\ContadorRemoto.aidl
 */
package br.livro.android.cap11.service.aidl;
public interface ContadorRemoto extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements br.livro.android.cap11.service.aidl.ContadorRemoto
{
private static final java.lang.String DESCRIPTOR = "br.livro.android.cap11.service.aidl.ContadorRemoto";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an br.livro.android.cap11.service.aidl.ContadorRemoto interface,
 * generating a proxy if needed.
 */
public static br.livro.android.cap11.service.aidl.ContadorRemoto asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof br.livro.android.cap11.service.aidl.ContadorRemoto))) {
return ((br.livro.android.cap11.service.aidl.ContadorRemoto)iin);
}
return new br.livro.android.cap11.service.aidl.ContadorRemoto.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_count:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.count();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements br.livro.android.cap11.service.aidl.ContadorRemoto
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
@Override public int count() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_count, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_count = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
}
public int count() throws android.os.RemoteException;
}
