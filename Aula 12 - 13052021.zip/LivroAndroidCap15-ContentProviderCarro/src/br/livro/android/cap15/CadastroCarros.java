package br.livro.android.cap15;

import java.util.ArrayList;

import android.content.Intent;
import android.database.Cursor;
import android.view.MenuItem;
import br.livro.android.cap14.banco.Carro;
import br.livro.android.cap14.banco.Carro.Carros;
import br.livro.android.cap14.banco.CarroListAdapter;

/**
 * Activity que demonstra o cadastro de carros:
 * 
 * - ListActivity: para listar os carros
 * - RepositorioCarro para salvar os dados no banco
 * - Carro
 * 
 * @author rlecheta
 *
 */
public class CadastroCarros extends br.livro.android.cap14.banco.CadastroCarros {
	
	@Override
	protected void atualizarLista() {
		// Busca os carros do nosso content provider: content://br.livro.android.provider.carro/carros
		Cursor cursor = getContentResolver().query(Carros.CONTENT_URI, null, null, null, null);

		// L� os carros do cursor
		this.carros = new ArrayList<Carro>();
		while (cursor.moveToNext()) {
			Carro c = new Carro();
			c.id 	= cursor.getInt(cursor.getColumnIndex(Carros._ID));
			c.ano 	= cursor.getInt(cursor.getColumnIndex(Carros.ANO));
			c.placa = cursor.getString(cursor.getColumnIndex(Carros.PLACA));
			c.nome 	= cursor.getString(cursor.getColumnIndex(Carros.NOME));
			this.carros.add(c);
		}
		// Fecha o cursor ao terminar de ler
		cursor.close();
		// Informa o adapter para exibir a lista de carros
		setListAdapter(new CarroListAdapter(this, this.carros));
	}

	@Override
	//Sobrescreve para informar a classe correta de EditarCarro e BuscarCarro
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		//Clicou no menu
		switch (item.getItemId()) {
			case INSERIR_EDITAR:
				//Abre a tela com o formul�rio para adicinoar
				startActivityForResult(new Intent(this, br.livro.android.cap15.EditarCarro.class), INSERIR_EDITAR);
				break;
			case BUSCAR:
				//Abre a tela para buscar o carro pelo nome
				startActivity(new Intent(this, br.livro.android.cap15.BuscarCarro.class));
			break;
		}
		return true;
	}

	@Override
	protected void editarCarro(int posicao) {
		// Recupera o carro selecionado
		Carro carro = this.carros.get(posicao);
		
		// Cria a intent para abrir a tela de editar (abre a activity do cap 15 que herda do cap14)
		Intent it = new Intent(this, br.livro.android.cap15.EditarCarro.class);
		//Passa o id do carro como par�metro
		it.putExtra(Carros._ID,carro.id);

		//Abre a tela de edi��o
		startActivityForResult(it, INSERIR_EDITAR);
	}
}