/** Automatically generated file. DO NOT MODIFY */
package br.livro.android.cap9.outros;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}