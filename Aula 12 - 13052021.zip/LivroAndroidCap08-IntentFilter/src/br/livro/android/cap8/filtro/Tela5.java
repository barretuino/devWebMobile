package br.livro.android.cap8.filtro;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class Tela5 extends Activity {

	@Override
	protected void onCreate(Bundle icicle) {
		super.onCreate(icicle);

		//idem Activity4
		//chamada pela CATEGORIA_DUPLICADA com a action "ABRIR_ACTIVITY"

		TextView text = new TextView(this);
		text.setText("Esta � a tela 5");
		setContentView(text);
	}
}
