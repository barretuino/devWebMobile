/** Automatically generated file. DO NOT MODIFY */
package br.livro.android.cap15.teste;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}