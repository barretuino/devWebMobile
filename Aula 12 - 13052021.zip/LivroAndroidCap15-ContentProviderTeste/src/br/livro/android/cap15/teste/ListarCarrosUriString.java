package br.livro.android.cap15.teste;

import android.app.ListActivity;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

/**
 * Demonstra a busca no content provider direto na URI sem utiliar nenhuma classe
 * 
 * Uri carros: content://br.livro.android.provider.carro/carros
 * 
 * @author ricardo
 * 
 */
public class ListarCarrosUriString extends ListActivity {
	private ArrayAdapter<String> carros;

	@Override
	public void onCreate(Bundle icicle) {
		super.onCreate(icicle);

		// Busca os carros content provider: content://br.livro.android.provider.carro/carros
		Cursor cursor = getContentResolver().query(Uri.parse("content://br.livro.android.provider.carro/carros"), null, null, null, null);

		// L� os carros do cursor
		carros = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
		while (cursor.moveToNext()) {
			int ano = cursor.getInt(cursor.getColumnIndex("ano"));
			String placa = cursor.getString(cursor.getColumnIndex("placa"));
			String nome = cursor.getString(cursor.getColumnIndex("nome"));
			this.carros.add(String.format("Nome [%s], Placa [%s], Ano [%d]", nome, placa, ano));
		}
		// Fecha o cursor ao terminar de ler
		cursor.close();
		// Informa o adapter para exibir a lista de carros
		setListAdapter(carros);
	}

	@Override
	protected void onListItemClick(ListView l, View v, int position, long itemId) {
		super.onListItemClick(l, v, position, itemId);

		String s = carros.getItem(position);

		Toast.makeText(this, "Carro selecionado: " + s,Toast.LENGTH_SHORT).show();

	}
}
