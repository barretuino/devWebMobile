package br.livro.android.cap15.teste;

import java.util.ArrayList;

import android.app.ListActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;
import br.livro.android.cap14.banco.Carro;
import br.livro.android.cap14.banco.Carro.Carros;
import br.livro.android.cap14.banco.CarroListAdapter;

/**
 * Demonstra a busca no content provider dos carros utilizando as classes do projeto 'LivroAndroidCap14-BancoDados-Library'
 * 
 * Assim podemos utilizar at� o adapter para listar os carros
 * 
 * Uri carros: content://br.livro.android.provider.carro/carros
 * 
 * @author ricardo
 * 
 */
public class ListarCarros extends ListActivity {
	private ArrayList<Carro> carros;

	@Override
	public void onCreate(Bundle icicle) {
		super.onCreate(icicle);

		// Busca os carros content provider: content://br.livro.android.provider.carro/carros
		Cursor cursor = getContentResolver().query(Carros.CONTENT_URI, null, null, null, null);

		// L� os carros do cursor
		carros = new ArrayList<Carro>();
		while (cursor.moveToNext()) {
			Carro c = new Carro();
			c.ano = cursor.getInt(cursor.getColumnIndex(Carros.ANO));
			c.placa = cursor.getString(cursor.getColumnIndex(Carros.PLACA));
			c.nome = cursor.getString(cursor.getColumnIndex(Carros.NOME));
			this.carros.add(c);
		}
		// Fecha o cursor ao terminar de ler
		cursor.close();
		// Informa o adapter para exibir a lista de carros
		setListAdapter(new CarroListAdapter(this, this.carros));
	}

	@Override
	protected void onListItemClick(ListView l, View v, int position, long itemId) {
		super.onListItemClick(l, v, position, itemId);

		Carro c = carros.get(position);

		Toast.makeText(this, "Carro selecionado: Id: " + c.id + ", Nome: " + c.nome + ", Placa: " + c.placa + ", Ano: " + c.ano,
				Toast.LENGTH_SHORT).show();

	}
}
