/** Automatically generated file. DO NOT MODIFY */
package br.livro.android.cap5;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}