/** Automatically generated file. DO NOT MODIFY */
package br.livro.android.cap4;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}